# MMOItems Default Resource Pack

This is the public repository for the default MMOItems resource pack.

## Download

In the top right corner of the repository, click the `Code` button, then under `Download source code`, select `ZIP`. You will download a ZIP version of the resource pack.

## Content

### Negative Space Font

> Credits goes to [AmberW](https://github.com/AmberWat/NegativeSpaceFont) for this resource.

You will find in this resource pack the [Negative Space Font](https://github.com/AmberWat/NegativeSpaceFont) shaded in.

### Example Tooltips

> All rights and credits go to the [Eclectic Trove](https://modrinth.com/resourcepack/eclectic-trove-legendary-tooltips) resource pack for the tooltip textures. They are not made by me, I adapted them to have them match the MMOItems format. They are licensed under `All Rights Reserved`, you are therefore **NOT allowed to use these tooltips on your server for commercial use**. I am only using these for demonstration purposes. The repo license (see `LICENSE`) does not apply to these materials as I do not own them.

You will find some examples of tooltip textures located in the folder `assets/mmoitems_example_tooltips`. The corresponding MMOItems config files can be found inside the default MMOItems  file named `MMOItems/tooltips/examples.yml`.

### Custom Blocks

You will find example block textures and model config files for MMOItems custom blocks.
- Block states are located in `assets/minecraft/blockstates`
- Item models are located in `assets/minecraft/item`
- Custom block models and textures are located in `assets/mmoitems_example_blocks`
